﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class GameController : MonoBehaviour {

	public GameObject asteroid;
	public GameObject ship;
	public AudioClip bgm;
	public AudioClip yay;
	public AudioClip sadviolin;
	public AudioSource bgmsource;
	public AudioSource gameoversource;

	private int score;
	private int hiscore;
	private int asteroidsRemaining;
	private int lives;
	private int wave;
	private int increaseEachWave = 4;
	private bool gameovercheck = false;

	public Text scoreText;
	public Text livesText;
	public Text waveText;
	public Text hiscoreText;
	public Text hiscoreMessage;
	public Text gameover;

	void Start () {

		bgmsource.clip = bgm;
		bgmsource.loop = true;
		//hiscore = PlayerPrefs.GetInt ("hiscore", 0);
		hiscore = 5;
		BeginGame ();
	}

	void Update () {

		if (Input.GetKey("escape"))
			Application.Quit();

		if (Input.GetKeyDown("space") && gameovercheck == true)
		{
			gameovercheck = false;
			gameover.text = "";
			ship.SetActive(true);
			BeginGame();
		}

	}

	void BeginGame(){
		bgmsource.clip = bgm;
		bgmsource.Play();
		score = 0;
		lives = 3;
		wave = 1;

		scoreText.text = "SCORE:" + score;
		hiscoreText.text = "HISCORE: " + hiscore;
		livesText.text = "LIVES: " + lives;
		waveText.text = "WAVE: " + wave;

		SpawnAsteroids();
	}

	void SpawnAsteroids(){

		DestroyExistingAsteroids();

		asteroidsRemaining = (wave * increaseEachWave);

		for (int i = 0; i < asteroidsRemaining; i++) {
			Instantiate(asteroid,
				new Vector3(Random.Range(-9.0f, 9.0f),
					Random.Range(-6.0f, 6.0f), 0),
				Quaternion.Euler(0,0,Random.Range(-0.0f, 359.0f)));

		}

		waveText.text = "WAVE: " + wave;
	}

	public void IncrementScore(){
		score++;

		scoreText.text = "SCORE:" + score;

		if (score > hiscore) {

			AudioSource.PlayClipAtPoint (yay, Camera.main.transform.position);
			hiscoreMessage.text = "NEW HISCORE!";
			Destroy (hiscoreMessage, 2f);
			hiscore = score;
			hiscoreText.text = "HISCORE: " + hiscore;
			PlayerPrefs.SetInt ("hiscore", hiscore);
		}
		if (asteroidsRemaining < 1) {

			wave++;
			SpawnAsteroids();

		}
	}

	public void DecrementLives(){
		lives--;
		livesText.text = "LIVES: " + lives;
		if (lives < 1) {
			GameOver();
		}
	}

	public void DecrementAsteroids(){
		asteroidsRemaining--;
	}

	public void SplitAsteroid(){
		asteroidsRemaining+=2;

	}

	void DestroyExistingAsteroids(){
		GameObject[] asteroids =
			GameObject.FindGameObjectsWithTag("Large Asteroid");

		foreach (GameObject current in asteroids) {
			GameObject.Destroy (current);
		}

		GameObject[] asteroids2 =
			GameObject.FindGameObjectsWithTag("Small Asteroid");

		foreach (GameObject current in asteroids2) {
			GameObject.Destroy (current);
		}
	}

	void GameOver(){
		bgmsource.clip = sadviolin;
		bgmsource.Play();
		gameovercheck = true;
		DestroyExistingAsteroids ();
		ship.SetActive (false);
		gameover.text = @"GAME OVER!
		
Press space to continue";

		}
}