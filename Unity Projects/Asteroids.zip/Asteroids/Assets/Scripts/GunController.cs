﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GunController : MonoBehaviour {

	public GameObject bullet;
	public AudioClip shoot;
	void Start() {

	}

	void FixedUpdate () {
		if (Input.GetKeyDown ("space"))
			ShootBullet ();
		
	}
	void ShootBullet(){

		Instantiate(bullet,
			new Vector3(transform.position.x,  
				transform.position.y, 0),
			transform.rotation);
		AudioSource.PlayClipAtPoint (shoot, Camera.main.transform.position);
	}
}
