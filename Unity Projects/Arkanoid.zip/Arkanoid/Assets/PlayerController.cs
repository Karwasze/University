﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {

	// Use this for initialization
	public float speed;
	private Rigidbody rb;
	private Vector3 playerPosition;
	void Start () 
	{
		rb = GetComponent<Rigidbody> ();
		playerPosition = gameObject.transform.position;
	}
	
	// Update is called once per frame
	void FixedUpdate () 
	{
		playerPosition.x += Input.GetAxis("Horizontal") * speed;
		transform.position = playerPosition;
		if (playerPosition.x < -20f) 
		{
			playerPosition = new Vector3 (-20f, playerPosition.y, playerPosition.z);
		} 
		if (playerPosition.x > 20f) 
		{
			playerPosition = new Vector3(20f, playerPosition.y, playerPosition.z);     
		}
	}
}
