﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class BallMovement : MonoBehaviour {

	// Use this for initialization
	public Rigidbody rb;
	private int score;
	public Text winText;
	public Text countText;

	void Start () 
	{
		score = 0;
		rb = GetComponent<Rigidbody>();
		rb.velocity = new Vector3(20.0f, 0.0f, 10.0f);
	}

	void OnCollisionEnter (Collision col)
	{
		if(col.gameObject.tag == "Cube")
		{
			score += 1;
			Destroy(col.gameObject);
			if (score < 25) 
			{
				countText.text = "Count: " + score;
			}
			if (score == 25) 
			{
				winText.text = "WYGRAŁEŚ";
			}
		}
	}
}
